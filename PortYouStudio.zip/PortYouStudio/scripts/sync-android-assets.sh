#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
ASSETS="$ROOT/android/app/src/main/assets"
rm -rf "$ASSETS/www" "$ASSETS/psych-template"
mkdir -p "$ASSETS/www" "$ASSETS/psych-template"
cp -R "$ROOT/app/." "$ASSETS/www/"
cp -R "$ROOT/templates/PsychEngine-Mod-Template/." "$ASSETS/psych-template/"
printf '%s\n' 'Android WebView assets and Psych mod template synced.'
