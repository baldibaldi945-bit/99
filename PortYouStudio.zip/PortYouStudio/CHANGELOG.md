# Changelog

## 0.2.0 — codecs, archives and app icon

- Added the supplied AxelzeroX23 artwork as the Android launcher icon, with only a slight edge crop and density resizing; preserved the untouched original in references/.
- Added 7-Zip-JBinding archive detection/extraction for 7z, RAR, TAR, GZip, BZip2 and other supported formats; ZIP-based FNMM files are detected by signature.
- Added a native Google astc-codec LDR decoder path to export ASTC textures as PNG.
- Restricted audio conversion to MP3/WAV inputs and OGG Vorbis output, retaining simultaneous multi-track mixing.
- Added offline codec-fetch scripts and Android NDK/CMake GitHub Actions steps.

## 0.1.0 — initial project source

- Created offline WebView application shell and Android host.
- Preserved user-provided UI artwork and audio assets.
- Added V-Slice and Funkin' Maker chart/archive conversion prototypes.
- Added Psych lane-side flip utility.
- Added Sparrow/JSON Spritemap and core Adobe Animate BTA reader.
- Added Funkin' Maker sprite strip atlas builder.
- Added ASTC header inspector and source asset preservation.
- Added limited Haxe/HScript pattern helper and WAV audio mixer.
- Added docs, tests and GitHub Actions Android debug build workflow.
