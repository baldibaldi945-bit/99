/* PortYou Studio chart conversion core.
 * ES5-only so the code can run in old Android WebViews.
 * The lane-side correction is explicit: flip note ownership 0..3 <-> 4..7.
 */
(function (root) {
  'use strict';

  function arr(v) { return Object.prototype.toString.call(v) === '[object Array]' ? v : []; }
  function obj(v) { return v && typeof v === 'object' && !isArray(v) ? v : {}; }
  function isArray(v) { return Object.prototype.toString.call(v) === '[object Array]'; }
  function num(v, fallback) { var n = Number(v); return isFinite(n) ? n : fallback; }
  function str(v, fallback) { return v === undefined || v === null ? (fallback || '') : String(v); }
  function clone(v) { return JSON.parse(JSON.stringify(v)); }
  function byTime(a, b) { return a[0] - b[0]; }
  function flipLane(lane) {
    lane = num(lane, 0);
    if (lane >= 0 && lane <= 3) return lane + 4;
    if (lane >= 4 && lane <= 7) return lane - 4;
    return lane;
  }
  function applySideFlip(sections, enabled) {
    var i, j, notes;
    if (!enabled) return sections;
    for (i = 0; i < sections.length; i++) {
      notes = arr(sections[i].sectionNotes);
      for (j = 0; j < notes.length; j++) {
        if (notes[j] && notes[j].length > 1) notes[j][1] = flipLane(notes[j][1]);
      }
    }
    return sections;
  }
  function groupEvents(events) {
    var map = {}, times = [], i, e, t;
    for (i = 0; i < events.length; i++) {
      e = events[i]; t = String(num(e[0], 0));
      if (!map[t]) { map[t] = []; times.push(t); }
      map[t].push(e[1]);
    }
    times.sort(function (a, b) { return Number(a) - Number(b); });
    var out = [];
    for (i = 0; i < times.length; i++) out.push([Number(times[i]), map[times[i]]]);
    return out;
  }
  function makeEmptySong(meta) {
    meta = obj(meta);
    return {
      song: {
        player1: str(meta.player1, 'bf'), player2: str(meta.player2, 'dad'),
        gfVersion: str(meta.gfVersion, 'gf'), stage: str(meta.stage, 'stage'),
        events: [], notes: [], song: str(meta.song, 'Converted Song'),
        needsVoices: meta.needsVoices !== false, validScore: true,
        bpm: num(meta.bpm, 120), speed: num(meta.speed, 1),
        arrowSkin: str(meta.arrowSkin, 'NOTE_assets'),
        splashSkin: str(meta.splashSkin, 'noteSplashes')
      }
    };
  }
  function createSections(notes, bpmEvents, focusEvents, defaultBpm, beatsPerSection, maxMs) {
    notes = arr(notes).slice().sort(byTime);
    bpmEvents = arr(bpmEvents).slice().sort(function (a, b) { return a.time - b.time; });
    focusEvents = arr(focusEvents).slice().sort(function (a, b) { return a.time - b.time; });
    var last = maxMs || (notes.length ? notes[notes.length - 1][0] : 0);
    var sections = [], t = 0, bpm = num(defaultBpm, 120), bi = 0, fi = 0, ni = 0;
    var focus = true, sectionLen, end, secNotes, changeBpm, guard = 0;
    if (last <= 0) last = 1;
    while (t <= last + 1 && guard < 100000) {
      guard++;
      changeBpm = false;
      while (bi < bpmEvents.length && bpmEvents[bi].time <= t + 1) {
        bpm = num(bpmEvents[bi].bpm, bpm); changeBpm = true; bi++;
      }
      while (fi < focusEvents.length && focusEvents[fi].time <= t + 1) {
        focus = !!focusEvents[fi].mustHit; fi++;
      }
      sectionLen = 60000 / Math.max(1, bpm) * (beatsPerSection || 4);
      end = t + sectionLen;
      secNotes = [];
      while (ni < notes.length && notes[ni][0] < end - 0.001) {
        if (notes[ni][0] >= t - 1) secNotes.push(notes[ni]);
        ni++;
      }
      sections.push({
        typeOfSection: 0, sectionBeats: beatsPerSection || 4,
        altAnim: false, gfSection: false, sectionNotes: secNotes,
        mustHitSection: focus, changeBPM: changeBpm, bpm: bpm
      });
      t = end;
    }
    return sections;
  }
  function getSliceFocus(v) {
    var c = (v && typeof v === 'object') ? v.char : v;
    // V-Slice char enum: 0=player, 1=opponent, 2=GF.
    return Number(c) !== 1;
  }
  function convertVSlice(chart, metadata, options) {
    chart = obj(chart); metadata = obj(metadata); options = obj(options);
    var diff = str(options.difficulty, 'normal').toLowerCase();
    var dataNotes = arr(obj(chart.notes)[diff]);
    var timeChanges = arr(metadata.timeChanges);
    var timeFormat = str(metadata.timeFormat, 'ms').toLowerCase();
    var timeScale = (timeFormat === 's' || timeFormat === 'sec' || timeFormat === 'seconds') ? 1000 : 1;
    var baseBpm = timeChanges.length ? num(timeChanges[0].bpm, 120) : num(options.bpm, 120);
    var output = makeEmptySong({
      player1: obj(obj(metadata.playData).characters).player || options.player1 || 'bf',
      player2: obj(obj(metadata.playData).characters).opponent || options.player2 || 'dad',
      gfVersion: obj(obj(metadata.playData).characters).girlfriend || options.gfVersion || 'gf',
      stage: obj(metadata.playData).stage || options.stage || 'stage',
      song: metadata.songName || options.song || 'Converted Song',
      bpm: baseBpm, speed: obj(chart.scrollSpeed)[diff] || obj(chart.scrollSpeed).default || 1,
      arrowSkin: options.arrowSkin || 'NOTE_assets', splashSkin: options.splashSkin || 'noteSplashes'
    });
    var rawNotes = [], focusEvents = [], bpmEvents = [], events = [], warnings = [];
    var i, n, e, focus;
    for (i = 0; i < dataNotes.length; i++) {
      n = dataNotes[i];
      if (!n || n.t === undefined || n.d === undefined) { warnings.push('Skipped malformed V-Slice note #' + i); continue; }
      rawNotes.push([num(n.t, 0) * timeScale, num(n.d, 0), num(n.l, 0) * timeScale, str(n.k || '')]);
    }
    // Later tempo changes live in metadata.timeChanges, not necessarily in chart.events.
    for (i = 1; i < timeChanges.length; i++) {
      bpmEvents.push({ time: num(timeChanges[i].t, 0) * timeScale, bpm: num(timeChanges[i].bpm, baseBpm) });
    }
    for (i = 0; i < arr(chart.events).length; i++) {
      e = chart.events[i];
      if (!e) continue;
      var eventTime = num(e.t, 0) * timeScale;
      if (e.e === 'FocusCamera') {
        focusEvents.push({ time: eventTime, mustHit: getSliceFocus(e.v) });
      } else if (e.e === 'BPM Change' || e.e === 'BPMChange') {
        bpmEvents.push({ time: eventTime, bpm: num(e.v && e.v.bpm !== undefined ? e.v.bpm : e.v, baseBpm) });
      }
      if (e.e === 'ChangeCharacter') {
        events.push([eventTime, ['Change Character', str(obj(e.v).character, 'dad'), str(obj(e.v).newchar, '')]]);
      } else if (e.e === 'PlayVideo') {
        var v = obj(e.v);
        events.push([eventTime, ['PortYou Play Video', str(v.path, ''), JSON.stringify(v)]]);
      } else if (e.e !== 'FocusCamera' && e.e !== 'BPM Change' && e.e !== 'BPMChange') {
        // Preserve the original event name and payload in a Psych custom-event row.
        events.push([eventTime, ['PortYou Unmapped Event', str(e.e, 'unknown'), JSON.stringify(e.v === undefined ? null : e.v)]]);
        warnings.push('Preserved but not auto-executed V-Slice event: ' + str(e.e, 'unknown') + ' @ ' + eventTime + 'ms');
      }
    }
    rawNotes.sort(byTime);
    focusEvents.sort(function (a, b) { return a.time - b.time; });
    bpmEvents.sort(function (a, b) { return a.time - b.time; });
    // This mirrors the supplied converter's FocusCamera handling. The user can reverse
    // both sides afterwards using the independent checkbox/button in the app.
    for (i = 0; i < rawNotes.length; i++) {
      n = rawNotes[i];
      var activeFocus = true, j;
      for (j = 0; j < focusEvents.length; j++) {
        if (focusEvents[j].time <= n[0]) activeFocus = focusEvents[j].mustHit;
        else break;
      }
      if (!activeFocus) n[1] = flipLane(n[1]);
    }
    output.song.notes = createSections(rawNotes, bpmEvents, focusEvents, baseBpm, 4, rawNotes.length ? rawNotes[rawNotes.length - 1][0] : 0);
    applySideFlip(output.song.notes, !!options.flipSides);
    output.song.events = groupEvents(events);
    return { chart: output, warnings: warnings, source: 'V-Slice', difficulty: diff };
  }

  function convertCodename(data, meta, options) {
    data = obj(data); meta = obj(meta); options = obj(options);
    var out = makeEmptySong({
      player1: options.player1 || 'bf', player2: options.player2 || 'dad',
      gfVersion: options.gfVersion || 'gf', stage: data.stage || options.stage || 'stage',
      song: options.song || 'Converted Song', bpm: num(options.bpm, 150), speed: num(data.scrollSpeed, 1),
      arrowSkin: options.arrowSkin, splashSkin: options.splashSkin
    });
    var allNotes = [], focusEvents = [], bpmEvents = [], events = [], warnings = [];
    var lines = arr(data.strumLines), i, j, line, n, pos, id, isPlayer;
    for (i = 0; i < lines.length; i++) {
      line = obj(lines[i]); pos = str(line.position, '');
      for (j = 0; j < arr(line.notes).length; j++) {
        n = line.notes[j];
        id = num(n.id, 0);
        isPlayer = pos === 'boyfriend' || pos === 'player' || Number(line.type) === 1;
        allNotes.push({ time: num(n.time, 0), id: id, len: num(n.sLen, 0), type: str(n.type || ''), player: isPlayer, position: pos });
      }
    }
    allNotes.sort(function (a, b) { return a.time - b.time; });
    var cam = false, bpm = num(options.bpm, 150), sectionLen, t = 0, ni = 0, fi = 0, bi = 0, last = allNotes.length ? allNotes[allNotes.length - 1].time : 1;
    for (i = 0; i < arr(data.events).length; i++) {
      var ev = data.events[i];
      if (ev.name === 'Camera Movement' || ev.name === 'Camera Movent Tween') focusEvents.push({ time: num(ev.time, 0), mustHit: Number(arr(ev.params)[0]) === 1 });
      if (ev.name === 'BPM Change') bpmEvents.push({ time: num(ev.time, 0), bpm: num(arr(ev.params)[0], bpm) });
      events.push([num(ev.time, 0), [str(ev.name, ''), str(arr(ev.params)[0], ''), arr(ev.params).slice(1).join(',')]]);
    }
    // Convert notes into absolute Psych lanes. A single section may contain both sides.
    var linear = [];
    for (i = 0; i < allNotes.length; i++) {
      n = allNotes[i]; id = n.id;
      if (n.player) id = (id % 4);
      else id = (id % 4) + 4;
      linear.push([n.time, id, n.len, n.type]);
    }
    var currentFocus = true;
    for (i = 0; i < focusEvents.length; i++) if (focusEvents[i].time <= 0) currentFocus = focusEvents[i].mustHit;
    out.song.notes = createSections(linear, bpmEvents, focusEvents, bpm, 4, last);
    applySideFlip(out.song.notes, !!options.flipSides);
    out.song.events = groupEvents(events);
    return { chart: out, warnings: warnings, source: 'Codename Engine' };
  }

  function convertFunkinMaker(data, eventsData, sceneData, options) {
    data = obj(data); eventsData = obj(eventsData); sceneData = obj(sceneData); options = obj(options);
    var bpm = num(data.bpm, 100), lines = arr(data.strumLines), raw = [], i, d, j, note, lineNotes;
    var warnings = [], events = [], output = makeEmptySong({
      player1: options.player1 || 'bf', player2: options.player2 || 'dad', gfVersion: options.gfVersion || 'gf',
      stage: options.stage || 'fnmm_stage', song: options.song || 'Converted Song', bpm: bpm,
      speed: 1, arrowSkin: options.arrowSkin, splashSkin: options.splashSkin
    });
    for (i = 0; i < lines.length; i++) {
      lineNotes = arr(lines[i]);
      for (d = 0; d < lineNotes.length; d++) {
        var lane = (i === 0 ? d : d + 4);
        for (j = 0; j < arr(lineNotes[d]).length; j++) {
          note = lineNotes[d][j];
          raw.push([Math.round(num(note.start, 0) * 1000), lane, Math.round(num(note.duration, 0) * 1000), '']);
        }
      }
    }
    raw.sort(byTime);
    if (lines.length > 2) warnings.push('Funkin Maker file has ' + lines.length + ' strum lines; only line 0 (player) and line 1 (opponent) are mapped automatically.');
    // Keep player ownership as the reference side; opponent notes use lane 4..7.
    var last = raw.length ? raw[raw.length - 1][0] : 1;
    var sectionLen = 60000 / Math.max(1, bpm) * 4, sections = [], t = 0, ni = 0, sNotes, guard = 0;
    while (t <= last + 1 && guard < 100000) {
      guard++; sNotes = [];
      while (ni < raw.length && raw[ni][0] < t + sectionLen) {
        if (raw[ni][0] >= t - 1) sNotes.push(raw[ni]);
        ni++;
      }
      sections.push({ typeOfSection: 0, sectionBeats: 4, altAnim: false, gfSection: false,
        sectionNotes: sNotes, mustHitSection: true, changeBPM: false, bpm: bpm });
      t += sectionLen;
    }
    applySideFlip(sections, !!options.flipSides);
    output.song.notes = sections;

    var evs = arr(eventsData.events), k, action, props, time;
    for (i = 0; i < evs.length; i++) {
      time = Math.round(num(evs[i].time, 0) * 1000);
      for (j = 0; j < arr(evs[i].actions).length; j++) {
        action = evs[i].actions[j]; props = obj(action.props);
        if (action.type === 'ObjectSpriteSet') {
          events.push([time, ['FNMM Object Sprite', str(props.object, ''), str(props.sprite, '')]]);
        } else if (action.type === 'ObjectChartChange') {
          events.push([time, ['FNMM Object Strumline', str(props.object, ''), str(props.strumLine, '')]]);
        } else {
          events.push([time, ['FNMM Unmapped Action', str(action.type, ''), JSON.stringify(props)]]);
          warnings.push('Unmapped Funkin Maker action: ' + str(action.type, 'unknown') + ' @ ' + time + 'ms');
        }
      }
    }
    output.song.events = groupEvents(events);
    var stage = buildFunkinMakerStage(sceneData, options);
    var spritePlan = buildFunkinMakerSpritePlan(options.spriteMeta || {});
    return { chart: output, stage: stage, spritePlan: spritePlan, warnings: warnings, source: 'Funkin Maker' };
  }

  function convertVSliceCharacter(characterData, characterId) {
    var c = obj(characterData), animations = arr(c.animations), out = [], i, a, off;
    for (i = 0; i < animations.length; i++) {
      a = obj(animations[i]); off = arr(a.offsets);
      out.push({
        anim: str(a.name, str(a.prefix, 'idle')),
        name: str(a.prefix, str(a.name, 'idle')),
        fps: num(a.frameRate, 24),
        loop: !!a.looped,
        indices: arr(a.frameIndices),
        offsets: [num(off[0], 0), num(off[1], 0)]
      });
    }
    var pos = arr(c.offsets), camera = arr(c.cameraOffsets), icon = obj(c.healthIcon);
    return {
      animations: out,
      image: str(c.assetPath, 'characters/' + str(characterId, 'character')),
      scale: num(c.scale, 1),
      sing_duration: num(c.singTime, 4),
      healthicon: str(icon.id, str(characterId, 'face')),
      position: [num(pos[0], 0), num(pos[1], 0)],
      camera_position: [num(camera[0], 0), num(camera[1], 0)],
      flip_x: !!c.flipX,
      no_antialiasing: !!c.isPixel,
      _portyou: { source: 'V-Slice character JSON', characterId: str(characterId, ''), renderType: str(c.renderType, 'unknown'), startingAnimation: str(c.startingAnimation, 'idle') }
    };
  }

  function convertVSliceStage(stageData, stageId) {
    var s = obj(stageData), inputProps = arr(s.props), props = [], i, p, pos, scroll, animations, convertedAnimations, j, a;
    for (i = 0; i < inputProps.length; i++) {
      p = obj(inputProps[i]); pos = arr(p.position); scroll = arr(p.scroll); animations = arr(p.animations); convertedAnimations = [];
      for (j = 0; j < animations.length; j++) {
        a = obj(animations[j]);
        convertedAnimations.push({ name: str(a.name, 'idle'), prefix: str(a.prefix, str(a.name, 'idle')), fps: num(a.frameRate, 24), indices: arr(a.frameIndices), loop: !!a.looped });
      }
      props.push({
        name: str(p.name, str(p.assetPath, 'stage_prop_' + i).split('/').pop()),
        image: str(p.assetPath, 'stages/' + str(stageId, 'stage')),
        x: num(pos[0], num(arr(p.offsets)[0], 0)), y: num(pos[1], num(arr(p.offsets)[1], 0)),
        scroll: [num(scroll[0], 1), num(scroll[1], 1)],
        scale: [num(p.scale, 1), num(p.scale, 1)], alpha: num(p.alpha, 1),
        angle: num(p.angle, 0), order: num(p.zIndex, i), animations: convertedAnimations,
        _portyou: { assetPath: str(p.assetPath, ''), sourceIndex: i }
      });
    }
    var chars = obj(s.characters), bf = obj(chars.bf), dad = obj(chars.dad), gf = obj(chars.gf);
    return {
      directory: str(s.directory, ''), defaultZoom: num(s.cameraZoom, 0.9), isPixelStage: false,
      boyfriend: arr(bf.position).length ? bf.position : [770, 100],
      opponent: arr(dad.position).length ? dad.position : [100, 100],
      girlfriend: arr(gf.position).length ? gf.position : [400, 130],
      hide_girlfriend: !!s.hideGirlfriend, camera_speed: 1, props: props,
      _portyou: { source: 'V-Slice stage JSON', stageId: str(stageId, ''), sourceCharacters: chars,
        cameraOffsets: { boyfriend: arr(bf.cameraOffsets), opponent: arr(dad.cameraOffsets), girlfriend: arr(gf.cameraOffsets) },
        sourceProps: inputProps }
    };
  }

  function convertVSliceLevel(levelData, levelId, songRows) {
    var l = obj(levelData), songs = arr(songRows), background = str(l.weekBackground, ''),
      outSongs = [], i, s;
    for (i = 0; i < songs.length; i++) {
      s = obj(songs[i]);
      outSongs.push([str(s.name, str(s.song, 'song')), str(s.icon, 'face')]);
    }
    return {
      songs: outSongs,
      weekCharacters: ['dad', 'bf', 'gf'],
      weekBackground: background || 'stage', weekBefore: '',
      storyName: str(l.name, str(levelId, 'Converted Week')),
      weekName: str(l.name, str(levelId, 'Converted Week')),
      startUnlocked: true, hideStoryMode: false, hideFreeplay: false,
      _portyou: { source: 'V-Slice level JSON', levelId: str(levelId, ''), titleAsset: str(l.titleAsset, ''), visualProps: arr(l.props), sourceSongs: arr(l.songs) }
    };
  }

  function buildFunkinMakerStage(scene, options) {
    scene = obj(scene); options = obj(options);
    var objects = arr(scene.objects), props = [], i, o, spr, line, x, y, scale, lower;
    var boyfriend = null, opponent = null, girlfriend = null, characterSprites = [];
    for (i = 0; i < objects.length; i++) {
      o = obj(objects[i]); spr = str(o.spr, 'object_' + i); line = num(o.strumLine, -1);
      x = num(o.x, 0); y = num(o.y, 0); scale = obj(o.scale); lower = spr.toLowerCase();
      if (line === 0 || /^(bf|boyfriend|player)$/.test(lower)) { boyfriend = [x, y]; characterSprites.push({ role: 'boyfriend', sprite: spr, x: x, y: y }); continue; }
      if (line === 1 || /^(dad|opponent)$/.test(lower)) { opponent = [x, y]; characterSprites.push({ role: 'opponent', sprite: spr, x: x, y: y }); continue; }
      if (/^(gf|girlfriend)$/.test(lower)) { girlfriend = [x, y]; characterSprites.push({ role: 'girlfriend', sprite: spr, x: x, y: y }); continue; }
      props.push({
        name: spr, image: 'stages/' + spr,
        x: x, y: y, scroll: [1, 1], scrollFactor: [1, 1],
        scale: [num(scale.x, 1), num(scale.y, 1)],
        alpha: o.visible === false ? 0 : 1, order: i, animated: false,
        _portyou: { fixed: !!o.fixed, sourceStrumLine: line }
      });
    }
    var cam = arr(scene.cameras)[0] || {};
    return {
      directory: '', defaultZoom: num(cam.scale, 1), isPixelStage: false,
      boyfriend: boyfriend || [770, 100], opponent: opponent || [100, 100], girlfriend: girlfriend || [400, 130],
      hide_girlfriend: !girlfriend, camera_speed: 1, props: props,
      _portyou: { source: 'Funkin Maker scene.json', camera: { x: num(cam.x, 0), y: num(cam.y, 0) }, landscape: !!scene.landscape,
        characterSprites: characterSprites, originalObjects: objects, icons: arr(scene.icons) }
    };
  }

  function buildFunkinMakerSpritePlan(spriteMeta) {
    var out = [], key;
    for (key in spriteMeta) if (Object.prototype.hasOwnProperty.call(spriteMeta, key)) {
      out.push({ sprite: key, mode: 'strip', definition: spriteMeta[key] });
    }
    return out;
  }

  function convertPsychChart(data) {
    data = obj(data); var song = obj(data.song), original = arr(song.notes), all = [], i, j, sec, n;
    for (i = 0; i < original.length; i++) {
      sec = obj(original[i]);
      for (j = 0; j < arr(sec.sectionNotes).length; j++) all.push(clone(sec.sectionNotes[j]));
    }
    all.sort(byTime);
    var last = all.length ? all[all.length - 1][0] : 1;
    var sections = [], t = 0, bpm = num(song.bpm, 120), si = 0, sectionLen, end, notes;
    while (t <= last + 1 && si < 100000) {
      sec = obj(original[si]);
      if (sec.changeBPM) bpm = num(sec.bpm, bpm);
      var beats = num(sec.sectionBeats, 4); sectionLen = 60000 / Math.max(1, bpm) * beats; end = t + sectionLen;
      notes = [];
      for (i = 0; i < all.length; i++) if (all[i][0] >= t - 1 && all[i][0] < end - 1) notes.push(clone(all[i]));
      sections.push({ typeOfSection: num(sec.typeOfSection, 0), sectionBeats: beats,
        altAnim: !!sec.altAnim, gfSection: !!sec.gfSection, sectionNotes: notes,
        mustHitSection: sec.mustHitSection !== undefined ? !!sec.mustHitSection : (si % 2 === 0),
        changeBPM: !!sec.changeBPM, bpm: bpm });
      t = end; si++;
    }
    var out = { song: {
      player1: song.player1, player2: song.player2, gfVersion: song.gfVersion, stage: song.stage,
      song: song.song, needsVoices: song.needsVoices, validScore: song.validScore,
      bpm: num(song.bpm, 120), speed: num(song.speed, 1), arrowSkin: song.arrowSkin || 'NOTE_assets',
      splashSkin: song.splashSkin || 'noteSplashes', notes: sections, events: arr(song.events)
    }};
    return out;
  }

  var api = {
    flipLane: flipLane, applySideFlip: applySideFlip, convertVSlice: convertVSlice,
    convertCodename: convertCodename, convertFunkinMaker: convertFunkinMaker,
    convertPsychChart: convertPsychChart, buildFunkinMakerStage: buildFunkinMakerStage,
    convertVSliceCharacter: convertVSliceCharacter, convertVSliceStage: convertVSliceStage, convertVSliceLevel: convertVSliceLevel
  };
  root.PortYouConverters = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
}(this));
