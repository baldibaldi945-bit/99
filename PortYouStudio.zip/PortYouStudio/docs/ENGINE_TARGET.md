# Psych Engine mobile target reference

This project prepares mod files for **Psych Engine 1.0.4 mobile builds**; it is not itself a fork or a copy of the game engine. The mobile engine reference inspected for this port is:

- `FunkinPortingMobile/Psych-Engine-1.0.4-Mobile` — https://github.com/FunkinPortingMobile/Psych-Engine-1.0.4-Mobile
- Psych Engine Lua API reference for 1.0+: https://shadowmario.github.io/psychengine.lua/

The mobile repository documents that Lua scripting and video cutscenes can be configured through its project settings. The Lua API reference separates scripts into stage, note-type, event, song, character and general scripts, with event scripts stored under `mods/My-Mod/custom_events/`, stage scripts under `mods/My-Mod/stages/`, note-type scripts under `mods/My-Mod/custom_notetypes/`, and global scripts under `mods/My-Mod/scripts/`. The output template preserves these folder conventions.

## Porting policy

- Generate only formats and API calls that are known from the target version or explicitly mark them for review.
- Preserve unknown chart event names and payloads in the report; do not silently drop them.
- A custom event file stub is not the same as a completed event implementation. Every custom event needs runtime validation against the exact mobile engine build.
- Haxe/HScript source is copied to `converted-assets/source/` for reference. The app's pattern converter is intentionally not described as a complete Haxe compiler.
- Verify video, shader, sprite, chart and custom-note behavior in the specific mobile engine distribution that will load the mod.

The converter template is based on the user's supplied Psych mod template. No source files from the engine repository are bundled in this project.
