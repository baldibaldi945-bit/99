# Android build notes

## Project configuration

- Application ID: `com.axelzerox23.portyou`
- Minimum Android API: 14 (Android 4.0)
- Target SDK: 28
- Compile SDK: 28
- Android Gradle Plugin: 3.2.1
- Expected Gradle version: 4.6
- Java toolchain: JDK 8
- No network permission is declared; conversion logic and UI assets are local.

## Build with Android Studio

1. Install a JDK 8 distribution and Android Studio that can load Android Gradle Plugin 3.2.1.
2. Install Android SDK Platform 28, Build Tools 28.0.3, CMake 3.10.2 and Android NDK 20.0.5594570.
3. From the repository root, fetch local codec sources/assets and sync the WebView bundle:

   ```bash
   sh scripts/fetch-native-deps.sh
   sh scripts/fetch-codecs.sh
   sh scripts/sync-android-assets.sh
   ```

4. Open the `android/` directory as the Gradle project.
5. Use Gradle 4.6 and JDK 8 for this legacy Android plugin.
6. Run the `assembleDebug` task.
7. Install `android/app/build/outputs/apk/debug/app-debug.apk` on a test device.

The project uses a local WebView page in `android/app/src/main/assets/www/`. The supplied Psych template is bundled separately in `android/app/src/main/assets/psych-template/` and copied into each output mod by the native bridge. Run `sh scripts/sync-android-assets.sh` after changing the web app or template; it updates both bundled copies. If you edit files under `app/`, copy the updated UI into the Android assets folder before building:

```sh
sh scripts/sync-android-assets.sh
```

## GitHub Actions

The workflow fetches the pinned ASTC decoder source and local OGG encoder, installs JDK 8, Gradle 4.6, Android SDK 28, CMake and NDK 20, then builds and uploads the debug APK as an Actions artifact. The first run must be checked to confirm JitPack/JNI builds successfully.

## Android 4 caveats

`minSdkVersion 14` configures the manifest minimum. It is not a verified compatibility certification. In particular, the audio mixer uses Web Audio (`AudioContext`) and a local OGG Vorbis encoder. The ASTC LDR module is native C++ and requires NDK/CMake. The archive reader includes 7-Zip native binaries. All runtime processing is offline after the dependencies are bundled into the APK, but old WebView/audio support and native ABIs must be tested on a real device. Verify file selection, output writing, canvas memory and music playback on a real Android 4 device.

The Java host imports ZIP/FNMM via streaming ZIP I/O and routes other supported formats through 7-Zip-JBinding auto-detection. Nevertheless, a 2GB archive can exceed available internal storage or heap indirectly when the JavaScript layer enumerates many files or builds image canvases. Use much smaller mods during initial testing.

## Build status

No APK is included because the current build environment did not have Gradle or Android SDK installed. The source configuration and CI workflow are included; this execution environment cannot run Gradle/Android SDK, so the native APK build and CI result remain unverified.
