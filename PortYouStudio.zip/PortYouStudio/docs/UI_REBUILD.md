# UI rebuild from the supplied page sketches

The supplied ZIPs included walkthrough sketches and screenshots for the stage, character, notes, shader, settings-language and friends screens. The walkthrough images are not shipped as app assets anymore. Their visible layout/interaction instructions were reimplemented in HTML, CSS, SVG and Canvas.

## Screens reconstructed

- **Stage editor:** dark camera viewport with grid/crosshair, live single-image preview, stage-role selector, layer label and code-drawn add-object toolbar. It is a working inspection viewport, not a full Psych Engine stage runtime.
- **Character builder:** dual preview/introduction layout, local PNG atlas preview, Sparrow XML/JSON metadata parser, animated frame-step preview with a frame strip, and existing Character JSON/offset/icon builders. The chosen image/metadata is loaded locally.
- **Notes / Hold editor:** four vector arrow lanes, hold strip, live opacity indicator and above/below selector. The existing PNG/XML merge/export logic remains wired to the real controls.
- **Shader Lab:** selected character image preview, transparent overlay preview, GLSL source reader and the brush/eraser/undo/redo mask canvas. It exports a mask and profile; a target shader/runtime loader is still needed to attach that mask in Psych.
- **Language selection:** CSS-drawn flags for Algeria, Syria, France, Thailand and Japan, with the original language selector state kept as the source of truth. CSS flags are used instead of emoji so older Android WebViews can display them.
- **Friends page:** code-built profile cards linked to the exact URLs supplied by the user.

## Original artwork retained

- All five supplied home-screen illustrations remain byte-identical.
- Settings illustrations 1–5, 7, 9–12 remain byte-identical. The language and friends sketches (6 and 8) were unfinished examples; those pages are drawn in code instead.
- The supplied launcher icon and untouched source image remain included.

## Size reduction

The old package stored the complete WebView `app/` tree twice: once under `app/` and again under `android/app/src/main/assets/www/`. The duplicate Android copy is no longer committed. `syncPortYouRuntimeAssets` in the Android Gradle module copies the web app and Psych template into Android assets automatically before `preBuild`; `scripts/sync-android-assets.sh` remains available for manual sync. This preserves the contents of the built app while shrinking the repository ZIP.
