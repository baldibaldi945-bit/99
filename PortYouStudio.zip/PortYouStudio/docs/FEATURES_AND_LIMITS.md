# Feature matrix and known limitations

| Area | Implemented in this source tree | Not claimed / requires follow-up |
|---|---|---|
| Offline UI | Bundled HTML/CSS/JS; original home/settings illustrations retained; editor examples rebuilt with CSS/SVG/Canvas; music and touch sound local | Native performance has not been profiled on Android 4 |
| Archive import and mod container | ZIP/FNMM signature routing plus 7-Zip-JBinding auto-detection for 7z, RAR, TAR, GZip, BZip2 and other formats supported by the included 7-Zip engine; traversal guard; 2GB compressed and expanded caps; each conversion seeds its output mod from the supplied Psych template | Depends on native 7-Zip binaries for the target ABI; encrypted/split archives may need passwords or every volume; low-storage phones may fail before the 2GB cap |
| V-Slice charts | Notes, tempo changes, focus camera ownership, known character/video events, unknown event payload retention | Unknown event runtime behavior requires custom Lua |
| Funkin' Maker charts | Two strumlines, note times/durations converted from seconds to milliseconds, source events preserved | Special object/strumline event semantics need per-mod Lua implementation |
| Side correction | Separate reversible 0–3 ↔ 4–7 swap in chart tools and archive option | The user should verify the source convention first |
| Characters | Coded workbench, atlas preview and animated frame strip; initial V-Slice character JSON field mapping | Special animations, atlas packing assumptions and engine-specific fields need in-game testing |
| Stages | Coded camera workspace with grid, single-image preview, layer toolbar and role selector; initial V-Slice stage mapping and Funkin' Maker scene object mapping | Unsupported object scripts, shader behavior and complex transforms may need manual reconstruction |
| Story/Freeplay | V-Slice levels may generate week JSON; absent level metadata creates Freeplay-only week | Story progression and backgrounds need in-game review |
| Sprite sheets | Sparrow XML/JSON parse; strip reconstruction; provisional frame/animation metadata | Original animation names are not inferred if source lacks them |
| BTA | Core `ATLAS.SPRITES`, `AN.TL`, `SD.S`, nested symbols, matrices, alpha, rotated sprite path | Full equivalence for color transforms, filters, masks, unusual 3D/tween features is not guaranteed |
| ASTC | JNI bridge to Google astc-codec for standard ASTC LDR 2D textures; saves PNG locally | ASTC HDR, 3D textures and images above the 2-megapixel defensive memory cap are not supported; NDK build and device testing are still required |
| Haxe/HScript | Small pattern library and visible TODO comments for unknown lines | Not a general Haxe compiler, not an arbitrary Haxe→Lua transpiler |
| Audio | MP3/WAV input, simultaneous start-time-zero mixing, OGG Vorbis output through a bundled local encoder | Web Audio decoding depends on WebView support; old Android 4 browsers may not expose AudioContext or decoders |
| Shaders | Coded character preview, transparent mask overlay, brush/eraser and undo/redo drawing surface; read/display shader text and preserve source | No shader language translation or exact effect recreation |
| Language | Code-built selector with CSS flags for five requested locales | Complete translation catalog is not finished |

## Why there is no artificial 9MB Haxe library

A large file size does not make code conversion more accurate. This version keeps a small auditable mapping set and marks unsupported code instead of padding the app with meaningless or unverified data. A robust future translator needs parsing, typed API mappings, engine-version profiles, and tests against actual Haxe mod scripts.

## ASTC decoder source audit

The newly attached `astc to png.zip` is a saved website snapshot. Its `astc-to-png.bin` is an HTML page (not a decoder binary), and the snapshot does not include a WASM/native decoder module. The project therefore integrates the independently licensed Google `astc-codec` LDR software decoder as native source downloaded by `scripts/fetch-native-deps.sh`; the converter is bundled in the APK after build. Original ASTC assets are still preserved unchanged. ASTC decode is not yet verified on an Android 4 device.
