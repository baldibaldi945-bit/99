# Format mapping notes

## Note lane convention

Psych charts use note lane indices 0–3 for one side and 4–7 for the other. PortYou keeps side correction explicit:

```text
0 ↔ 4
1 ↔ 5
2 ↔ 6
3 ↔ 7
```

This is a separate operation after converting the source convention. It must not be automatically applied to every chart: the original source's ownership can vary. The converter preserves its own interpretation and lets the user deliberately reverse it.

## V-Slice time and focus

- Notes are read from the chosen difficulty's `notes` array.
- Millisecond time is kept; `s`, `sec`, and `seconds` metadata is scaled by 1000.
- `timeChanges` are carried into Psych section BPM changes.
- `FocusCamera` is used to assign note ownership based on the focus convention found in the source and the supplied chart conversion reference.
- `ChangeCharacter` and `PlayVideo` are mapped to PortYou/Psych event rows where possible.

## Funkin' Maker time and lanes

For the supplied sample, line 0 is assigned to player lanes 0–3 and line 1 to opponent lanes 4–7. Note `start` and `duration` values are seconds, so they are multiplied by 1000. Event timestamps are treated the same way.

## Character and stage files

V-Slice character and stage JSON are not copied as if they were Psych files. The converter maps fields it recognizes into a Psych-shaped output and preserves source metadata under `_portyou` to assist manual completion. Check animation names, image keys, positions, offsets, camera offsets, z-order and antialiasing in the target engine.

## Week / Freeplay behavior

When a V-Slice level can be read and its song IDs are matched, a week JSON and a generated week artwork placeholder are produced. Otherwise, the output week is flagged as Freeplay-only. Funkin' Maker sample does not provide a source story-week definition, so the converter uses a Freeplay-only placeholder week.
