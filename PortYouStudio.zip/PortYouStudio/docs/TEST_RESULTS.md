# Validation notes

Validation was run against the files the user supplied in this conversation. The original mod archives themselves are not bundled in this repository; only format findings and the small ASTC note-skin example are retained.

## Real chart function checks

| Supplied sample | Output from the chart conversion functions | Result |
|---|---:|---|
| V-Slice Enterprise chart, `normal` | 1,425 notes, 138 sections, 8 event groups | Converted by `convertVSlice`; no warnings in the chart function result |
| Funkin' Maker sample | 219 notes, 39 sections, 1 event group, 1 mapped scene prop | Converted by `convertFunkinMaker`; no warnings in the chart function result |

The V-Slice chart check was run on the supplied `enterprise-chart.json` and `enterprise-metadata.json`. The Funkin' Maker check used the supplied `data.json`, `events.json` and `scene.json`. These are chart-function checks, **not** a full gameplay validation of the complete archive output inside Psych Engine.

## Sprite and asset checks

- The supplied `ReRun_NOTE_assets.astc` has a valid ASTC header: 12×12×1 block, 1166×1166×1 image extent (1,359,556 pixels), within the new 2-megapixel native decoder guard. Native decode is implemented in source but was not compiled or run in this environment.
- Unit tests check lane swapping, V-Slice BPM changes, preservation of unmapped event payloads, Funkin' Maker note-time conversion, Sparrow XML parsing, BTA atlas metadata parsing and character JSON offsets/health-bar RGB.
- The retained home/settings artwork is kept byte-for-byte from its nested ZIP sources. Walkthrough images for character, notes, shader and stage have been replaced by coded interfaces and removed from the app bundle. ASTC note-skin reference files remain unchanged.

## New checks in this revision

- `node tests/test_audio_tools.js` verifies that only `.mp3` and `.wav` input names are accepted and the declared output is OGG. This is a format-policy test, not an actual codec round-trip.
- The supplied `.FNMM` sample starts with ZIP local-file signature `PK\x03\x04`, confirming ZIP-container detection is the correct import path for that sample.
- The new launcher icon has all six required density image dimensions (36, 48, 72, 96, 144, 192 px); the untouched uploaded original is also preserved in `references/app_icon_original.png`.
- Android ZIP/FNMM + 7-Zip extraction, native ASTC decoding, and MP3/WAV-to-OGG encoding are source integrations; they are not yet runtime-tested on an APK or physical handset.

## Not verified

- No APK was built because this environment has no Gradle installation or Android SDK.
- No test was run on a physical Android 4 handset. `minSdkVersion 14` is a build target setting, not a device compatibility certificate.
- No converted chart has been played through an actual Psych Engine 1.0.4 mobile runtime here.
- Complex Haxe/HScript, unknown chart events, BTA colour effects, detached Hold draw order, native ASTC runtime decoding, OGG encoding on WebView and shader-to-character attachment remain incomplete or require device/engine-side testing.

## UI and packaging checks

- JavaScript syntax, unit tests, duplicate HTML ids and references to missing element ids were checked after the UI reconstruction.
- The retained artwork is limited to the original home and selected settings illustrations; coded UI components replace the walkthrough screenshots.

## Packaging checks

- The 15 retained home/settings illustrations were compared byte-for-byte with their user-supplied ZIP originals.
- The WebView `www/` directory and Android `psych-template/` directory are generated during Gradle `preBuild` from the single source copies in `app/` and `templates/`; they are intentionally not committed twice.
- All 32 files in the supplied Psych mod template remain stored once in `templates/`; the native template seeding code uses the generated Android assets at runtime.
- `scripts/sync-android-assets.sh` remains the manual sync entry point.
