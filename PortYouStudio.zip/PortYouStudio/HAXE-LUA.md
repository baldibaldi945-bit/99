# Haxe/HScript → Lua helper: supported scope

The current helper is an intentionally limited pattern translator. It is not a syntax-tree translator and cannot safely infer the behavior of arbitrary Haxe, HScript, Flixel, or mod-specific APIs.

## Current examples

| Source expression pattern | Lua-oriented output |
|---|---|
| `trace(value)` | `debugPrint(value)` |
| `FlxG.camera.zoom = value` | `setProperty('camGame.zoom', value)` |
| `FlxG.camera.alpha = value` | `setProperty('camGame.alpha', value)` |
| `FlxG.camera.angle = value` | `setProperty('camGame.angle', value)` |
| `PlayState.instance.health += value` | `setProperty('health', getProperty('health') + value)` |
| `FlxG.sound.music.stop()` | `stopSound('')` |
| `FlxG.sound.play(path)` | `playSound(path)` |
| `game.camHUD.flash(duration)` | `cameraFlash('hud', duration)` |
| `Countdown.skipCountdown()` | `startCountdown()` |
| `game.health = value` | `setProperty('health', value)` |
| `game.currentCameraZoom = value` | `setProperty('defaultCamZoom', value)` |
| `Paths.sound('name')` / `Paths.music('name')` | simple relative asset string |

Some lifecycle callback declarations are converted to Lua function declarations. Basic typed `var` declarations for a small set of primitive types are simplified.

## Unsupported constructs

Classes, inheritance, imports with runtime behavior, anonymous functions, generics, enums, complex conditions, loops, switch statements, typed collections, Flixel objects, asset atlases, cameras, shader systems, custom note logic, and engine internals are not comprehensively translated. These must be manually rewritten for the installed Psych Engine 1.0.4 mobile build.

Every unrecognized line becomes `-- TODO_PORTYOU:` and is listed in the report. Review the whole generated Lua file before enabling it in a mod.

## Why the code library is not 9MB

Do not judge translator coverage by stored byte count. A compact, tested mapping is safer than a 9MB dump of unverified snippets. Future rules should be added only with: a source example, target Psych 1.0.4 API evidence, a minimal Lua output, and an automated test. See the engine references in the project README.
