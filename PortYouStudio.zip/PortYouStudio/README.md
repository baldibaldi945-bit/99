# PortYou Studio — AxelzeroX23

An offline-first Android/WebView toolkit for preparing Friday Night Funkin' V-Slice and Funkin' Maker mods for Psych Engine 1.0.4.

**Status:** source project / debug build pipeline. This is not a device-certified APK. Conversion is loss-aware; unrecognised engine-specific behavior is reported instead of silently removed.

## Included

- Original supplied UI artwork preserved byte-for-byte; supplied AxelzeroX23 icon used as Android launcher art with a slight inset crop and six density sizes.
- Android WebView host targeting API 14 (Android 4.0) and target SDK 28.
- ZIP/FNMM import (FNMM ZIP containers are detected by signature) plus 7-Zip auto-detection for 7z, RAR, TAR, GZip, BZip2 and other supported formats; 2GB compressed and expanded caps with path traversal protection.
- V-Slice and Funkin' Maker chart/mod conversion prototypes, including a reversible Psych lane-side flip.
- Sparrow XML/JSON Spritemap parsing, Funkin' Maker strip reconstruction and a core Adobe Animate BTA reader.
- Native ASTC LDR to PNG decode path through JNI; original ASTC files are preserved. HDR and 3D ASTC are not supported in this path.
- MP3/WAV input to OGG Vorbis output, including simultaneous track mixing.
- Psych mod template, conversion reports, and Node tests.

## Build

From the repository root, run:

```sh
sh scripts/fetch-native-deps.sh
sh scripts/fetch-codecs.sh
sh scripts/sync-android-assets.sh
```

Then open `android/` with JDK 8, Gradle 4.6, Android SDK 28, NDK 20 and CMake 3.10.2, or let `.github/workflows/android-debug.yml` build a debug APK. Network is needed only while fetching third-party source/assets at build time; the packaged app is intended to perform conversion offline.

## Important limitations

- Haxe/HScript translation is a limited pattern helper, not a complete compiler. Unmatched lines remain visible as TODOs.
- ASTC decoder supports the LDR profile only and is capped at 2 megapixels for older-device memory safety; it has not been tested on an Android 4 handset here.
- Audio accepts MP3/WAV only and produces OGG Vorbis only. Decoding depends on Web Audio support in the device WebView, which may be absent or incomplete on old Android versions.
- 7-Zip library supports several archive types; password-protected and split archives may need passwords or all volumes.
- Unknown chart events, special scene objects, and complex shader behavior still need event-specific Lua and in-engine tests.
- `minSdkVersion 14` is the configured minimum, not a compatibility certification. A real Android 4 device test and a successful CI build are still required.
- 2GB is a hard input/extraction ceiling, not a guarantee that a low-memory phone can process an archive of that size.

See `README.ar.md`, `docs/BUILD_ANDROID.md`, `docs/FEATURES_AND_LIMITS.md`, `docs/ASTC_INPUT_AUDIT.md`, `docs/TEST_RESULTS.md`, and `THIRD_PARTY_NOTICES.md`.

**@AxelzeroX23 by tha apk**
