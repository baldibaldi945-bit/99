# Third-party notices

- **Google astc-codec** — ASTC LDR software decoder, Apache License 2.0. Source is fetched at the pinned commit by `scripts/fetch-native-deps.sh` and compiled into the Android library.
- **OggVorbisEncoder.js / libogg / libvorbis** — Ogg Vorbis encoder for browser JavaScript. The upstream project documents a MIT wrapper/API component and BSD-like licensing for libogg/libvorbis. `scripts/fetch-codecs.sh` downloads its minified JS, memory initializer, and upstream license file into the bundled `app/js/vendor/` folder.
- **7-Zip-JBinding-4Android** — Android archive extraction library, distributed via JitPack. Its upstream repository declares LGPL-2.1; the RAR decompression source carries an unRAR restriction. This project uses extraction only. The LGPL-2.1 text is included in `THIRD_PARTY_LICENSES/LGPL-2.1.txt`. Before publishing an APK, review the LGPL requirements for replaceable native libraries and the additional upstream notices.

Upstream project references:
- https://github.com/google/astc-codec
- https://github.com/higuma/ogg-vorbis-encoder-js
- https://github.com/omicronapps/7-Zip-JBinding-4Android

This project does not bundle their upstream source files in this source archive; the build scripts retrieve them before compiling/bundling.
