# PortYou Studio — AxelzeroX23

تطبيق أندرويد محلي لتجهيز ونقل مودات Friday Night Funkin' إلى بنية Psych Engine 1.0.4، مع أدوات مستقلة للشارتات والسبرايتات والأطالس والصوت وملفات Haxe/HScript.

> **الحالة:** هذه نسخة مصدرية أولى قابلة للتطوير، وليست إصدار APK نهائياً مختبراً على جهاز Android 4. لا أزعم أن كل مود يُحوَّل آلياً 100%؛ التحويلات التي تعتمد على كود المحرك أو مؤثرات غير معروفة تُسجَّل في تقرير بدلاً من حذفها بصمت.

## ما بداخل المشروع

- واجهة HTML/CSS/JavaScript محلية بالكامل، مع الاحتفاظ برسومات الصفحة الرئيسية ومجموعة رسومات الإعدادات الفنية. أُعيد بناء صفحات محررات الشخصية والأسهم والـShaders والستاج برمجياً وفق رسوماتك، بدلاً من عرض صور الشرح كواجهات ثابتة. صفحة اللغات والأصدقاء أصبحت عناصر واجهة فعلية. صورة `app_icon.png` التي أرسلتها أصبحت أيقونة تشغيل Android بعد قص داخلي خفيف وإنتاج أحجام mipmap الستة؛ احتفظت بالملف الأصلي دون تعديل في `references/app_icon_original.png`. 
- تطبيق Android WebView، `minSdkVersion 14` (Android 4.0/API 14) و`targetSdkVersion 28`.
- استيراد ZIP وFNMM (عندما يكون حاوية ZIP) و7z وRAR وTAR وGZip وBZip2 وصيغ أخرى يتعرف عليها 7-Zip؛ مع حماية مسارات الاستخراج وحد 2GB للمدخل والمفكوك. قد تختلف الصيغ المدعومة باختلاف الأرشيف ومكتبة 7-Zip المضمنة.
- تحويل أساسي لأرشيفات V-Slice وFunkin' Maker إلى مسودة مود Psych Engine.
- تحويل شارت V-Slice، Codename، وFunkin' Maker؛ وأداة مستقلة لقلب جهتي أسهم Psych بين المسارات 0–3 و4–7.
- قراءة Sparrow XML وJSON Spritemap، وفك تجميع شرائط Funkin' Maker إلى أطلس PNG/XML.
- قارئ أساسي لبنية Adobe Animate BTA: `ATLAS.SPRITES` و`AN.TL` و`SD.S`، وإعادة رسم الفريمات المركبة في Sparrow atlas.
- فك ملفات ASTC القياسية ذات ملف LDR إلى PNG محلياً عبر مكتبة native مبنية داخل APK. ملفات ASTC الأصلية وأمثلة ASTC/XML التي أرسلتها محفوظة كما هي ضمن `references/astc-note-skin/`؛ فك HDR غير مدعوم.
- تجهيز إعدادات الأسهم، عرض طبقات الستاج، قراءة ملفات shader، ومترجم أنماط Haxe/HScript المعروفة إلى Lua مع أسطر TODO للمراجعة.
- تحويل MP3 أو WAV إلى OGG Vorbis؛ ويمكن مزج عدة مسارات معاً في الوقت نفسه، مع انتهاء الناتج عند انتهاء أطول مسار. يحتاج WebView إلى دعم Web Audio لفك الملفات.
- قالب Psych Engine Mod Template الذي أرسلته يُضمّن داخل التطبيق ويُنسخ فعلياً إلى مجلد `mods/اسم_المود` عند بدء كل تحويل؛ كما يتضمن المحوّل الأصلي واختبارات التحويل.

## حجم المشروع ورفع GitHub

أصول الواجهة محفوظة مرة واحدة فقط داخل `app/assets`. لا تُخزّن نسخة ثانية من الصفحة داخل `android/app/src/main/assets`: مهمة Gradle `syncPortYouRuntimeAssets` تنسخ ملفات الويب وقالب Psych تلقائياً عند البناء. هذا يجعل مستودع المصدر أصغر، مع بقاء ملفات APK المضمنة كاملة.

## فتح المستودع

1. ارفع محتويات هذا المجلد إلى مستودع GitHub جديد.
2. افتح مجلد `android` في Android Studio أو استخدم إعداد CI الموجود في `.github/workflows/android-debug.yml`.
3. ابنِ نسخة Debug من المشروع.
4. ثبّت APK الناتج على جهاز اختبار قبل استخدامه مع مودات كبيرة.

تفاصيل البناء: [`docs/BUILD_ANDROID.md`](docs/BUILD_ANDROID.md). معلومات المحرك المستهدف: [`docs/ENGINE_TARGET.md`](docs/ENGINE_TARGET.md)، ونتائج اختبار ملفاتك: [`docs/TEST_RESULTS.md`](docs/TEST_RESULTS.md).

## استخدام التطبيق

1. شغّل PortYou Studio واضغط «إضافة أرشيف مود».
2. اختر مود V-Slice أو أرشيف Funkin' Maker المضغوط.
3. استخدم الكشف التلقائي أو اختر نوع المود يدوياً.
4. فعّل «قلب جهة النوتات» فقط عندما تكون جهات اللاعب والخصم معكوسة في المصدر أو في نتيجة التحويل.
5. اقرأ التقرير؛ ثم اضغط «تصدير ZIP الناتج».
6. افتح الناتج على نسخة Psych Engine 1.0.4 التي تستهدفها، وراجع الأحداث والستاج والشخصيات قبل النشر.

## حدود مهمة — اقرأها قبل الاعتماد

- **Haxe/HScript → Lua:** المترجم الحالي مساعد أنماط محدود، وليس مترجماً كاملاً للغة. الأسطر غير المعروفة تظل `TODO_PORTYOU` ويجب إعادة كتابتها وفحصها.
- **ASTC:** فك ASTC LDR مضمّن في بناء Android من خلال `google/astc-codec`، مع حد أمان للصورة وذاكرة الأجهزة القديمة. لا يدعم HDR أو كل Footprint ثلاثي الأبعاد. يجب تشغيل `scripts/fetch-native-deps.sh` قبل البناء.
- **BTA:** يدعم المسار الأساسي للفريمات والطبقات والرموز والتحويلات الخطية والشفافية. بعض مؤثرات اللون والفلاتر والخصائص الخاصة قد لا تنتقل بصورة مطابقة.
- **الأحداث:** أحداث V-Slice المعروفة مثل تغيير الشخصية والفيديو لها تحويل أولي. الأحداث الأخرى تحفظ مع بياناتها وتحتاج Lua مخصصاً. أحداث Funkin' Maker الخاصة بالكائنات محفوظة لكن تنفيذ سلوك كل كائن يحتاج ربطاً يدوياً.
- **أسماء الحركات:** عينة Funkin' Maker لا تعطي أسماء حركات واضحة؛ أسماء الحركات الناتجة أولية وتحتاج تأكيداً.
- **الصوت:** المدخلات MP3 وWAV فقط، والمخرج OGG Vorbis فقط. يمكن مزج عدة ملفات بالتزامن، لكن قراءة الملفات تعتمد على Web Audio المدعوم في WebView؛ Android 4 القديم قد لا يدعم فك بعض ملفات MP3/WAV.
- **التحويل إلى Story Mode:** إذا لم يوجد تعريف مستوى/أسبوع صالح، ينشأ أسبوع مخفي من Story Mode ليظهر في Freeplay. خلفية الأسبوع التي ينشئها التطبيق خلفية نصية بديلة وليست رسماً أصلياً للمود.
- **الذاكرة:** حد 2GB هو حد الاستيراد والفك، وليس ضماناً أن الهاتف سيعالج موداً بهذا الحجم؛ مساحة التخزين وRAM وحدود صور Canvas تؤثر.
- **التوافق:** إعداد minSdk يستهدف API 14، لكن لم يتم بناء APK أو اختباره على جهاز Android 4 داخل بيئة التطوير هذه. جرّبه على جهاز فعلي قبل اعتباره مدعوماً نهائياً.
- **اللغات:** واجهة اللغة موجودة كبداية، لكن الترجمة الكاملة لكل النصوص لم تكتمل.

التفاصيل موثقة في [`docs/FEATURES_AND_LIMITS.md`](docs/FEATURES_AND_LIMITS.md) و[`docs/SOURCE_AUDIT.md`](docs/SOURCE_AUDIT.md) و[`docs/USER_UI_INSTRUCTIONS.md`](docs/USER_UI_INSTRUCTIONS.md).

## الروابط داخل التطبيق

- Instagram — AxelzeroX23: https://www.instagram.com/axelzerox023?cnvx=MXA0aWgzcTY2dDk2Zg==
- YouTube — Akram Makak: https://youtube.com/@akrammakak-official?si=XEtTBDSdL5YANMoy
- Norah Game Over: https://youtube.com/@norahgameover23?si=aywbvnVVbwcGqm5_
- Akram Makak: https://youtube.com/@akrammakak-official?si=Z44cVlZlfFbKM8vJ
- Sonic: https://youtube.com/@sonicfnf-2?si=vdy5zqkp-pbJZ3I0
- Remas Cute Art: https://youtube.com/@remas_cute_art?si=9lPEgv-bl0taqifp
- Vanessa Gaming: https://youtube.com/@vanessagamingph1?si=qgwjsPWSdfSYGSqu
- Y4npiero: https://youtube.com/@y4npi3r0?si=GfDsX4dOUFJQ9h3A

لم يصل رابط قناة يوتيوب الخاصة بصاحب التطبيق في الرسالة، لذلك لم أضع رابطاً غير معروف.

## بناء الاعتمادات الأوفلاين

قبل البناء المحلي شغّل:

```bash
sh scripts/fetch-native-deps.sh
sh scripts/fetch-codecs.sh
sh scripts/sync-android-assets.sh
```

يُضمّن مصدر ASTC LDR ومكتبة OGG داخل APK الناتج؛ لا يحتاج التطبيق إلى إنترنت أثناء الاستخدام. يدعم مستخرج 7-Zip التنسيقات الموضحة في وثائق المكتبة، ومنها 7z وRAR وTAR وGZip وBZip2 وZIP. ملف FNMM المرفق كان ZIP فعلياً (توقيع `PK`) لذلك يُفتح عبر مسار ZIP مع الاحتفاظ باسم/امتداد الملف الأصلي.

## الاختبارات

```bash
node tests/test_converters.js
node --check app/js/app.js
node --check app/js/converters.js
node --check app/js/sprite-tools.js
node --check app/js/audio-tools.js
```

الاختبارات الحالية تختبر تحويل المسارات، أمثلة شارت V-Slice/Funkin' Maker، قراءة Sparrow XML، وفحص ترويسة ASTC، وقائمة امتدادات الصوت المسموح بها. لا تختبر كل أنواع مودات المجتمع ولا تضمن تطابق الأحداث المعقدة.

## الحقوق

واجهة التطبيق ورسوماتها محفوظة من الملفات التي أرسلها AxelzeroX23 دون إعادة رسم. كود PortYou Studio الجديد منظم لأغراض التطوير والتجربة. ملفات القوالب والمراجع المرفقة تحتفظ بأصلها؛ راجع تراخيص أصحابها قبل إعادة توزيعها.

**@AxelzeroX23 by tha apk**
