package com.axelzerox23.portyou;

/** Native ASTC LDR file decoder backed by the pinned Google astc-codec source. */
public final class AstcCodec {
    private AstcCodec() { }
    public static native byte[] decodeAstc(byte[] astcFile);
    static {
        System.loadLibrary("portyou_astc");
    }
}
